package com.securityv2.Springsecurityv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springsecurityv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
