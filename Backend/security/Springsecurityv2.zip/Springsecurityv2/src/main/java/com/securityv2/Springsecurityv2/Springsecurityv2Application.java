package com.securityv2.Springsecurityv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springsecurityv2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springsecurityv2Application.class, args);
	}

}
