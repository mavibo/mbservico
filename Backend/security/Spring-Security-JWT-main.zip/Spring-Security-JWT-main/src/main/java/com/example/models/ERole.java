package com.example.models;

public enum ERole {
    ADMIN,
    USER,
    INVITED
}
