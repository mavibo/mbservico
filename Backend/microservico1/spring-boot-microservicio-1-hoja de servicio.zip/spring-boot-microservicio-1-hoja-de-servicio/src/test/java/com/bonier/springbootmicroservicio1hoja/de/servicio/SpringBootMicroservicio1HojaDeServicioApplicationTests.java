package com.bonier.springbootmicroservicio1hoja.de.servicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroservicio1HojaDeServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
